# SI-Munics
Lab 3.
The file lab3.py uses a text message.
lab3-image.py uses an image.